package com.example.esd_project.Model;

import lombok.Data;

@Data
public class SpecializationCreditsDTO {
    Integer studentId;
    String studentName;
    String name;
    Double credits;
}
