package com.example.esd_project;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EsdProjectApplication {

    public static void main(String[] args) {
        SpringApplication.run(EsdProjectApplication.class, args);
    }

}
